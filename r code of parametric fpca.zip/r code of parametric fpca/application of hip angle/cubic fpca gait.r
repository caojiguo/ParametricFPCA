# open a new graph window in R in a Windows laptop.
# run quartz() if you are using a Mac computer

install.packages(c("fda","caTools"))

library(fda)
data(gait)
hipangle <- gait[,,"Hip Angle"]
time.range <- c(0,1)
time.obs <- seq(from=0.025,to=0.975,by=0.05)
timebasis.four <- create.fourier.basis(c(0, 1), nbasis=65, period=1)

Lcoef        = c(0,(2*pi/diff(time.range))^2,0)
harmaccelLfd = vec2Lfd(Lcoef, time.range)


# open a new graph window in R in a Windows laptop.
# run quartz() if you are using a Mac computer
windows()
par(mfrow=c(1,1),lwd=3,cex.lab=1.2,oma=c(0,1,0,0))
matplot(x=time.obs, y=hipangle,type="l",xlab="Time", ylab="Hip Angle")


##=====================================
# choosing tuning parameter

loglam <- -9:-1
nlam = length(loglam)
 # vector to contain d.o.f
gcvsave = rep(NA,nlam)
for (i in 1:nlam) {
  lambda   = 10^loglam[i]
  fdParobj.har  = fdPar(timebasis.four, harmaccelLfd, lambda)
  smoothlist = smooth.basis(time.obs,hipangle,fdParobj.har,dfscale=1.2)
  gcvsave[i] = sum(smoothlist$gcv)
}

# open a new graph window in R in a Windows laptop.
# run quartz() if you are using a Mac computer
windows()
plot(y=gcvsave,x=loglam,xlab="log(Lam)",ylab="gcv")
lamb <- 10^(loglam[which.min(gcvsave)])
#10^(-7)
hipangle.fit <- smooth.basisPar(argvals=time.obs,
                              y=hipangle, fdobj=timebasis.four,
                              Lfdobj=harmaccelLfd, lambda=lamb)

hipangle.fd  = hipangle.fit$fd


#nonparametric FPCA
hipangle.pcalist.four = pca.fd(hipangle.fd, nharm=3)
hipangle.pcalist.four$varprop
#0.72665578 0.12292653 0.08497002
coef.four <- hipangle.pcalist.four$harmonics$coefs

randfd1.four = fd(coef.four[,1],timebasis.four)
randfd2.four = fd(coef.four[,2],timebasis.four)
randfd3.four = fd(coef.four[,3],timebasis.four)
fdvals1.four = eval.fd(time.obs,randfd1.four)
fdvals2.four = eval.fd(time.obs,randfd2.four)
fdvals3.four = eval.fd(time.obs,randfd3.four)

weight.1 <- hipangle.pcalist.four$values[1]/sum(hipangle.pcalist.four$values[1:3])
weight.2 <- hipangle.pcalist.four$values[2]/sum(hipangle.pcalist.four$values[1:3])
weight.3 <- 1 - weight.1 - weight.2


library(caTools)
# using monomial basis to approximate the fpca eigenfuction
p <- 2:6
dist <- numeric(length(p))
for(j in p)
{ #j = 2
timebasis.mon <- create.monomial.basis(c(0,1), j+1)
fdParobj.mon= fdPar(timebasis.mon,int2Lfd(0),lambda=0)
#parametric FPCA
hipangle.pcalist.mon = pca.fd(hipangle.fd, nharm=3, fdParobj.mon)
coef.mon <- hipangle.pcalist.mon$harmonics$coefs
randfd1.mon = fd(coef.mon[,1],timebasis.mon)
fdvals1.mon = eval.fd(time.obs,randfd1.mon)
randfd2.mon = fd(coef.mon[,2],timebasis.mon)
fdvals2.mon = eval.fd(time.obs,randfd1.mon)
randfd3.mon = fd(coef.mon[,3],timebasis.mon)
fdvals3.mon = eval.fd(time.obs,randfd1.mon)

dist[j-1] <- weight.1*trapz(x=time.obs, y=abs(fdvals1.mon-fdvals1.four)) + 
  weight.2*trapz(x=time.obs, y=abs(fdvals2.mon-fdvals2.four)) + 
  weight.3*trapz(x=time.obs, y=abs(fdvals3.mon-fdvals3.four))
}


windows()
par(lwd=3,cex.lab=1.6, font.lab=2,mar=c(5,4.8,4,2))
plot(x=p, y=dist, xlab="p", ylab="J(p)",type="l")




#eigenfunctions 
timebasis.mon <- create.monomial.basis(c(0,1), 5)
fdParobj.mon= fdPar(timebasis.mon,int2Lfd(0),lambda=0)
#parametric FPCA
hipangle.pcalist.mon = pca.fd(hipangle.fd, nharm=3, fdParobj.mon)
coef.mon <- hipangle.pcalist.mon$harmonics$coefs
randfd1.mon = fd(coef.mon[,1],timebasis.mon)
randfd2.mon = fd(coef.mon[,2],timebasis.mon)
randfd3.mon = fd(coef.mon[,3],timebasis.mon)

sum(hipangle.pcalist.mon$values[1:3]/sum(hipangle.pcalist.four$values))
# 0.72596509 0.11532614 0.08351721

# open a new graph window in R in a Windows laptop.
# run quartz() if you are using a Mac computer
windows()
par(mfrow=c(1,3),lwd=3,cex.lab=1.2)
plot(randfd1.mon,lty=1,ylim=c(0.65,1.26),xlab="time",ylab="FPC 1")
points(x=time.obs,y=fdvals1.four,type="l",lty=2)
legend(0.2,1.2,legend=c("P-FPCA","NP-FPCA"),bty="n",
       lty=1:2)


plot(randfd2.mon,lty=1,ylim=c(-1.7,1.2),xlab="time",ylab="FPC 2")
points(x=time.obs,y=fdvals2.four,type="l",lty=2)
legend(0.02,-1,legend=c("P-FPCA","NP-FPCA"),bty="n",
       lty=1:2)


plot((-1)*randfd3.mon,lty=1,ylim=c(-1.35,1.51),
     xlab="time",ylab="FPC 3")
points(x=time.obs,y=fdvals3.four,type="l",lty=2)
legend(0.2,-0.5,legend=c("P-FPCA","NP-FPCA"),bty="n",
       lty=1:2)




