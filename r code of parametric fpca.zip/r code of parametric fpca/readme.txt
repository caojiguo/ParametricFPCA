Eight folders are included. Seven of them contain the R codes and 
the relevant data set (if not available from R package) for analyzing the seven application examples; both parametric and nonparametric FPCA are employed for comparison. The remaining folder has the R codes for the simulation study.

application of Canadian weather: analysis of log precipitation data from 35 Canadian weather stations 
application of CD4: analysis of longitudinal CD4 counts
application of DTI: analysis of diffusion tensor imagining data
application of gene expression: analysis of gene expression data
application of girl height: analysis of girl height data
application of hip angle: analysis of hip angle data
application of medfly: analysis of egg number from medfly data

simulation study: "simulation of outlier.R" is the R code file for the simulation study to justify the robustness of parametric FPCA.
