install.packages(c("fda","refund","caTools"))

library(refund)
library(fda)

data(DTI)
str(DTI)
head(DTI)
length(DTI$case)
index.health <- which(DTI$case == 0)
length(index.health)
#42
length(which(DTI$case == 1))
#340
str(DTI$cca)
head(DTI$cca)


cca.health <- DTI$cca[index.health,]
dim(cca.health)
#42 93

# open a new graph window in R in a Windows laptop.
# run quartz() if you are using a Mac computer

windows()
matplot(t(cca.health),type="l",xlab="Tract distance",ylab="cca")


#=========================================
#functional data analysis
timepts=seq(0,92,1)
## create cubic B-spline basis functions, class 'basisfd'
bspline.basis=create.bspline.basis(rangeval=c(0,92),nbasis=95,4,timepts)
# for parametric fpca
basismat   = eval.basis(timepts, bspline.basis);
D2Lfd <- int2Lfd(m=2)




#=======================================
#choosing tuning parameter for smoothing
loglam <- seq(-2,4,by=0.5)
nlam = length(loglam)
dfsave  = rep(NA,nlam)  # vector to contain d.o.f
gcvsave = rep(NA,nlam)
for (i in 1:nlam) {
  #i=1
  lambda   = 10^loglam[i]
  fdParobj = fdPar(bspline.basis, int2Lfd(2), lambda)
  smoothlist = smooth.basis(timepts, t(cca.health),fdParobj,dfscale=1.2)
  dfsave[i]  = smoothlist$df
  gcvsave[i] = sum(smoothlist$gcv)
}

# open a new graph window in R in a Windows laptop.
# run quartz() if you are using a Mac computer

windows()
plot(y=gcvsave, x=loglam,xlab="log(lambda)", ylab="gcv")

#choose level off
lamb <- 10^(loglam[8])
#31.62278

#fdPar = fdPar(bspline.basis, 2, lamb)
cca.fit <- smooth.basisPar(argvals=timepts,
                            y=t(cca.health), fdobj=bspline.basis,
                            Lfdobj=D2Lfd, lambda=lamb)
cca.fd=cca.fit$fd 

fdParobj.bs <- fdPar(bspline.basis,int2Lfd(2), lambda=lamb)

PCAobjects.bs=pca.fd(cca.fd, nharm = 3, fdParobj.bs)
sum(PCAobjects.bs$values)
sum(PCAobjects.bs$varprop)



# open a new graph window in R in a Windows laptop.
# run quartz() if you are using a Mac computer


library(caTools)
weight.1 <- PCAobjects.bs$values[1]/sum(PCAobjects.bs$values[1:3])
weight.2 <- PCAobjects.bs$values[2]/sum(PCAobjects.bs$values[1:3])
weight.3 <- 1 - weight.1 - weight.2

coef.bs <- PCAobjects.bs$harmonics$coefs
randfd1.bs = fd(coef.bs[,1],bspline.basis)
pc1.bs = eval.fd(timepts,randfd1.bs)
randfd2.bs = fd(coef.bs[,2],bspline.basis)
pc2.bs = eval.fd(timepts,randfd2.bs)
randfd3.bs = fd(coef.bs[,3],bspline.basis)
pc3.bs = eval.fd(timepts,randfd3.bs)

sig <- sign(cbind(pc1.bs, pc2.bs, pc3.bs)[1,])

p <- 2:6
dist <- numeric(length(p))
for(j in p)
{ #j = 2
  dtibasis.mon <- create.monomial.basis(c(0,92), (j+1))
  fdParobj.mon= fdPar(dtibasis.mon,int2Lfd(0),lambda=0)
  dti.pcalist.mon = pca.fd(cca.fd, nharm=3, fdParobj.mon)
  coef.mon <- dti.pcalist.mon$harmonics$coefs
  randfd1.mon = fd(coef.mon[,1],dtibasis.mon)
  pc1.mon = eval.fd(timepts,randfd1.mon)
  pc1.mon <- sig[1]*sign(pc1.mon[1])*pc1.mon
  randfd2.mon = fd(coef.mon[,2],dtibasis.mon)
  pc2.mon = eval.fd(timepts,randfd2.mon)
  pc2.mon <- sig[2]*sign(pc2.mon[1])*pc2.mon
  randfd3.mon = fd(coef.mon[,3],dtibasis.mon)
  pc3.mon = eval.fd(timepts,randfd3.mon)
  pc3.mon <- sig[3]*sign(pc3.mon[1])*pc3.mon
  
  dist[j-1] <- weight.1*trapz(x=timepts, y=abs(pc1.mon-pc1.bs)) + 
    weight.2*trapz(x=timepts, y=abs(pc2.mon-pc2.bs)) + weight.3*trapz(x=timepts, y=abs(pc3.mon-pc3.bs))
  
}

windows()
par(lwd=3,cex.lab=1.6, font.lab=2,mar=c(5,4.8,4,2))
plot(x=p, y=dist, xlab="p", ylab="J(p)", type="l")

dtibasis.mon <- create.monomial.basis(c(0,92), 5)
fdParobj.mon= fdPar(dtibasis.mon,int2Lfd(0),lambda=0)
dti.pcalist.mon = pca.fd(cca.fd, nharm=3, fdParobj.mon)
coef.mon <- dti.pcalist.mon$harmonics$coefs
randfd1.mon = fd(coef.mon[,1],dtibasis.mon)
pc1.mon = eval.fd(timepts,randfd1.mon)
randfd2.mon = fd(coef.mon[,2],dtibasis.mon)
pc2.mon = eval.fd(timepts,randfd2.mon)
randfd3.mon = fd(coef.mon[,3],dtibasis.mon)
pc3.mon = eval.fd(timepts,randfd3.mon)

dti.pcalist.mon$values[1:3]/sum(PCAobjects.bs$values)
#tobs = timepts
windows()
par(mfrow=c(1,3),lwd=3,cex.lab=1.2)
plot(timepts,pc1.bs,type = "l",xlab="Tract distance",ylab="FPC 1",lty=2)
points(x=timepts,y=pc1.mon,type="l",lty=1)
legend(20,0.13,legend=c("P-FPCA","NP-FPCA"),bty="n",lty=1:2)

plot(timepts,pc2.bs,type = "l",xlab="Tract distance", ylab="FPC 2",lty=2)
points(x=timepts,y=pc2.mon,type="l",lty=1)
legend(20,0.2,legend=c("P-FPCA","NP-FPCA"),bty="n",lty=1:2)

plot(timepts,pc3.bs,type = "l",xlab="Tract distance",ylab="FPC 3",lty=2)
points(x=timepts,y=pc3.mon,type="l",lty=1)
legend(20,0.2,legend=c("P-FPCA","NP-FPCA"),bty="n",lty=1:2)
