


install.packages(c("fda","caTools"))
library(fda)

#provide working directory of the data file
Gene <- read.table("U:/data set/gene58rep34.txt",header=T)
head(Gene)
unique(Gene$gene)
table(Gene$gene)

#=============================================
#take F10 out
gene.10 <- Gene[Gene$gene=="F10",]
head(gene.10)
dim(gene.10)

# open a new graph window in R in a Windows laptop.
# run quartz() if you are using a Mac computer
windows()
matplot(t(gene.10[,2:11]),type="l",xlab="Time point", ylab="Gene expression")


#=============================================
timepts=seq(1,10,1)
# norder=4 ## cubic B-spline
# nbasis=norder+length(timepts)-2; (nbasis)

## create cubic B-spline basis functions, class 'basisfd'
bspline.basis=create.bspline.basis(rangeval=c(1,10),nbasis=12)
basismat   = eval.basis(timepts, bspline.basis);
D2Lfd <- int2Lfd(m=2)

#=======================================
#choosing tuning parameter for smoothing
loglam <- seq(-1,6,by=1)
nlam = length(loglam)
dfsave  = rep(NA,nlam)  # vector to contain d.o.f
gcvsave = rep(NA,nlam)
for (i in 1:nlam) {
  lambda   = 10^loglam[i]
  fdParobj = fdPar(bspline.basis, int2Lfd(2), lambda)
  smoothlist = smooth.basis(timepts, t(gene.10[,2:11]),fdParobj)
  dfsave[i]  = smoothlist$df
  gcvsave[i] = sum(smoothlist$gcv)
}

# open a new graph window in R in a Windows laptop.
# run quartz() if you are using a Mac computer
windows()
plot(x=loglam,y=gcvsave,xlab="log(Lambda)",ylab="gcv")

#level off point
lamb <- 10^loglam[3]
#fdPar = fdPar(bspline.basis, 2, lamb)
gene.fit <- smooth.basisPar(argvals=timepts,
                              y=t(gene.10[,2:11]), fdobj=bspline.basis,
                              Lfdobj=D2Lfd, lambda=lamb)
gene.fd=gene.fit$fd 

PCAobjects.bs=pca.fd(gene.fd, nharm = 3)
PCAobjects.bs$varprop
#0.8054887 0.1233406 0.0653428



timepts.fine <- seq(1,10,.2)
basismat.fine   = eval.basis(timepts.fine, bspline.basis);

pc1.bs <- basismat.fine%*%PCAobjects.bs$harmonics$coefs[,1]
pc2.bs <- basismat.fine%*%PCAobjects.bs$harmonics$coefs[,2]

#parametric fpca 

p <- 1:6

library(caTools)
weight.1 <- PCAobjects.bs$values[1]/sum(PCAobjects.bs$values[1:2])
weight.2 <- 1 - weight.1
p <- 1:5
dist <- numeric(length(p))
for(j in p)
{ 
mon.basis <- create.monomial.basis(c(1,10), j+1)
basismat.mon.fine <- eval.basis(timepts.fine,mon.basis)
fdParobj.mon= fdPar(mon.basis,int2Lfd(0),lambda=0)
PCAobjects.mon=pca.fd(gene.fd, nharm = 2,fdParobj.mon)
pc1.mon <- basismat.mon.fine%*%PCAobjects.mon$harmonics$coefs[,1]
pc2.mon <- basismat.mon.fine%*%PCAobjects.mon$harmonics$coefs[,2]
dist[j] <- weight.1*trapz(x=timepts.fine, y=abs(pc1.mon-pc1.bs)) + 
  weight.2*trapz(x=timepts.fine, y=abs(pc2.mon-pc2.bs))
}

windows()
pdf("order of gene.pdf")
par(lwd=3,cex.lab=1.6, font.lab=2,mar=c(5,4.8,4,2))
plot(x=p, y=dist, xlab="p", ylab="J(p)", type="l")
dev.off()
#choose p = 2
mon.basis <- create.monomial.basis(c(1,10), 3)
basismat.mon.fine <- eval.basis(timepts.fine,mon.basis)
fdParobj.mon= fdPar(mon.basis,int2Lfd(0),lambda=0)
PCAobjects.mon=pca.fd(gene.fd, nharm = 2,fdParobj.mon)
pc1.mon <- basismat.mon.fine%*%PCAobjects.mon$harmonics$coefs[,1]
pc2.mon <- basismat.mon.fine%*%PCAobjects.mon$harmonics$coefs[,2]

PCAobjects.mon$values/sum(PCAobjects.bs$values)
#0.80536850 0.12270279 0.06495164 
#===============================

mon.basis <- create.monomial.basis(c(1,10), 4)



# open a new graph window in R in a Windows laptop.
# run quartz() if you are using a Mac computer
#tobs = timepts
windows()
par(mfrow=c(1,2),lwd=3,cex.lab=1.2,mar=c(5,4.8,4,2))
plot(timepts.fine,pc1.bs,type = "l",xlab="Time",ylab="FPC 1",lty=2)
points(x=timepts.fine,y=pc1.mon,type="l",lty=1)
legend(2,0.2,legend=c("P-FPCA","NP-FPCA"),bty="n",lty=1:2)

plot(timepts.fine,pc2.bs,type = "l",xlab="Time",ylab="FPC 2",lty=2)
points(x=timepts.fine,y=pc2.mon,type="l",lty=1)
legend(4,-0.2,legend=c("P-FPCA","NP-FPCA"),bty="n",lty=1:2)

# plot(timepts.fine,basismat.fine%*%PCAobjects.bs$harmonics$coefs[,3],type = "l",xlab="Time",
#      ylab="FPC 3",lty=2)
# points(x=timepts.fine,y=basismat.mon.fine%*%PCAobjects.mon$harmonics$coefs[,3],
#        type="l",lty=1)
# legend(3,0.6,legend=c("P-FPCA","NP-FPCA"),
#        bty="n",lty=1:2)





#===================
#only nonparametric fpca

# open a new graph window in R in a Windows laptop.
# run quartz() if you are using a Mac computer
windows()
par(mfrow=c(1,3),lwd=3,cex.lab=1.2,oma=c(0,1,0,0))
plot(timepts.fine,basismat.fine%*%PCAobjects.bs$harmonics$coefs[,1],type = "l",xlab="Time",
     ylab="FPC 1",lty=1)
plot(timepts.fine,basismat.fine%*%PCAobjects.bs$harmonics$coefs[,2],type = "l",xlab="Time",
     ylab="FPC 2",lty=1)

plot(timepts.fine,basismat.fine%*%PCAobjects.bs$harmonics$coefs[,3],type = "l",xlab="Time",
     ylab="FPC 3",lty=1)


