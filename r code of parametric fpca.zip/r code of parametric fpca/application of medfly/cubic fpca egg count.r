

install.packages(c("fda","caTools"))

library(fda)
#provide directory of the RData
load("U:/data set/medfly.RData",verbose=T)


windows() # open a new graph window in R in a Windows laptop.
# run quartz() if you are using a Mac computer
par(lwd=3,cex.lab=1.2,oma=c(0,1,0,0))
matplot(medfly$eggcount,type="l",x=0:25,xlab="Day",ylab="Egg Count")


eggbasis.bs = create.bspline.basis(c(0, 25),nbasis=28,norder=4,
                                   breaks=0:25)
Lfdobjheight<- int2Lfd(2)
egg.count <- medfly$eggcount
#====================================
#choosing tuning parameter
loglam <- 1:6
nlam = length(loglam)
gcvsave = rep(NA,nlam)
for (i in 1:nlam) {
  #i=1
  lambda   = 10^loglam[i]
  fdParobj = fdPar(eggbasis.bs, int2Lfd(2), lambda)
  smoothlist = smooth.basis(0:25, egg.count,fdParobj,dfscale=1.2)
  gcvsave[i] = sum(smoothlist$gcv)
}

# open a new graph window in R in a Windows laptop.
# run quartz() if you are using a Mac computer
windows()
plot(x=loglam,y=gcvsave,type="l",xlab="Log(lam)",ylab="gcv")

lamb <- 10^(loglam[which.min(gcvsave)])
#100, deep rather than shallow

egg <- smooth.basisPar(argvals=0:25,
                          y=egg.count, fdobj=eggbasis.bs,
                          Lfdobj=Lfdobjheight, lambda=lamb)
egg.fd = egg$fd

# open a new graph window in R in a Windows laptop.
# run quartz() if you are using a Mac computer
windows()
plot(egg.fd,xlab="Day",ylab="Egg Count")

#  a principal components analysis
nharm = 3
#nonparametric fpca
egg.pcalist.bs = pca.fd(egg.fd, nharm=3)
#variance proportation explained
egg.pcalist.bs$varprop
# 0.62205406 0.29487474 0.06094105
sum(egg.pcalist.bs$varprop)

coef.bs <- egg.pcalist.bs$harmonics$coefs
timepts <- seq(0, 25, length.out=200)
randfd1.bs = fd(coef.bs[,1],eggbasis.bs)
pc1.bs = eval.fd(timepts,randfd1.bs)
randfd2.bs = fd(coef.bs[,2],eggbasis.bs)
pc2.bs = eval.fd(timepts,randfd2.bs)
randfd3.bs = fd(coef.bs[,3],eggbasis.bs)
pc3.bs = eval.fd(timepts,randfd3.bs)


# open a new graph window in R in a Windows laptop.
# run quartz() if you are using a Mac computer
windows()
par(mfrow=c(1,3),lwd=3,cex.lab=1.2,oma=c(0,1,0,0))
plot(x=timepts,y=pc1.bs,type="l",lty=1,xlab="Day",ylab="FPC 1")
plot(x=timepts,y=pc2.bs,type="l",lty=1,xlab="Day",ylab="FPC 2")
plot(x=timepts,y=pc3.bs,type="l",lty=1,xlab="Day",ylab="FPC 3")


#=============================
#choosing p

library(caTools)
weight.1 <- egg.pcalist.bs$values[1]/sum(egg.pcalist.bs$values[1:2])
weight.2 <- 1 - weight.1
p <- 2:6
dist <- numeric(length(p))
for(j in p)
{ #j = 2
  eggbasis.mon <- create.monomial.basis(c(0,25), (j+1))
  fdParobj.mon= fdPar(eggbasis.mon,int2Lfd(0),lambda=0)
  egg.pcalist.mon = pca.fd(egg.fd, nharm=2, fdParobj.mon)
  coef.mon <- egg.pcalist.mon$harmonics$coefs
  randfd1.mon = fd(coef.mon[,1],eggbasis.mon)
  pc1.mon = eval.fd(timepts,randfd1.mon)
  randfd2.mon = fd(coef.mon[,2],eggbasis.mon)
  pc2.mon = eval.fd(timepts,randfd2.mon)
  dist[j-1] <- weight.1*trapz(x=timepts, y=abs(pc1.mon-pc1.bs)) + 
    weight.2*trapz(x=timepts, y=abs(pc2.mon-pc2.bs))
  
}


windows()
par(lwd=3,cex.lab=1.6, font.lab=2,mar=c(5,4.8,4,2))
plot(x=p, y=dist, xlab="p", ylab="J(p)", type="l")

#choose p = 3


eggbasis.mon <- create.monomial.basis(c(0,25), 4)
fdParobj.mon= fdPar(eggbasis.mon,int2Lfd(0),lambda=0)
#parametric fpca
egg.pcalist.mon = pca.fd(egg.fd, nharm=3, fdParobj.mon)
egg.pcalist.mon$values[1:3]/sum(egg.pcalist.bs$values)
# 0.62202188 0.29442105 0.06057843




coef.mon <- egg.pcalist.mon$harmonics$coefs
pc1.mon = fd(coef.mon[,1],eggbasis.mon)
pc2.mon = fd(coef.mon[,2],eggbasis.mon)
pc3.mon = fd(coef.mon[,3],eggbasis.mon)

# open a new graph window in R in a Windows laptop.
# run quartz() if you are using a Mac computer


#K = 2
windows()
par(mfrow=c(1,2),lwd=3,cex.lab=1.2,mar=c(5,4.8,4,2))
plot(pc1.mon,lty=1,xlab="time",ylab="FPC 1")
points(x=timepts,y=pc1.bs,type="l",lty=2)
legend(5,0.15,legend=c("P-FPCA","NP-FPCA"),bty="n",
       lty=1:2)


plot(pc2.mon,lty=1,xlab="time",ylab="FPC 2")
points(x=timepts,y=pc2.bs,type="l",lty=2)
legend(5,-0.2,legend=c("P-FPCA","NP-FPCA"),
       bty="n",lty=1:2)