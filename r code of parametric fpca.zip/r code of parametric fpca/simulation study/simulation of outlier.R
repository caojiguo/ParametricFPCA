

install.packages(c("fda","mgcv","mvtnorm"))

library(fda)
library(mgcv)
library(mvtnorm)

#provide directory of RData
load("U:/data set/medfly.RData",verbose=T)

# open a new graph window in R in a Windows laptop.
# run quartz() if you are using a Mac computer
windows()
matplot(medfly$eggcount,type="l",x=0:25,xlab="time",ylab="Egg Count")


eggbasis.bs = create.bspline.basis(c(0, 25),nbasis=50)
Lfdobjheight<- int2Lfd(2)
fdParobj.bs <- fdPar(eggbasis.bs, int2Lfd(2), lambda=0)
eggbasis.mon <- create.monomial.basis(c(0,25), 4)
fdParobj.mon= fdPar(eggbasis.mon,int2Lfd(0),lambda=0)

m <- 100
timepts.fine <- seq(0,25,length.out=m)
basismat.fine <- eval.basis(timepts.fine, eggbasis.bs)
basismat.mon <- eval.basis(timepts.fine, eggbasis.mon)
egg.count <- medfly$eggcount

#=============================================
#choose the smoothing parameter to smooth each curve 
loglam <- 1:6
nlam = length(loglam)
gcvsave = rep(NA,nlam)
for (i in 1:nlam) {
  #i=1
  lambda   = 10^loglam[i]
  fdParobj = fdPar(eggbasis.bs, int2Lfd(2), lambda)
  smoothlist = smooth.basis(0:25, egg.count,fdParobj,dfscale=1.2)
  gcvsave[i] = sum(smoothlist$gcv)
}
windows()
plot(x=loglam,y=gcvsave,xlab="log(lambda)",ylab="gcv")

lamb <- 10^(loglam[which.min(gcvsave)])
egg <- smooth.basisPar(argvals=0:25,
                       y=egg.count, fdobj=eggbasis.bs,
                       Lfdobj=Lfdobjheight, lambda=lamb)
egg.fd = egg$fd

PCAobjects.bs=pca.fd(egg.fd, nharm = 6)
#PCAobjects.mon=pca.fd(gene.fd, nharm = 3,fdParobj.mon)
PCAobjects.bs$varprop[1:3]
#0.6220541449 0.2948744699 0.0609411159 
#take the first 3 PCs, which can explain over 97.8% of the variability of the 
#smoothed functional data




#=============================================

FPC.true <- basismat.fine%*%PCAobjects.bs$harmonics$coefs[,1:3]
FPC.out <- basismat.fine%*%PCAobjects.bs$harmonics$coefs[,4:5]

eigv.true <- PCAobjects.bs$values[1:3]
eigv.out <- PCAobjects.bs$values[4:5]
mean.curve <- c(basismat.fine %*% mean(egg.fd)$coefs)

N <- 200
#m <- 100
sim.dat <- matrix(0, nrow=N, ncol=m)


#==============================================
cat("FPCA without outliers\n")

#compare parametric(P) and nonparametric(NP) FPCA without outliers


n <- 100
N <- 200
sig <- sign(FPC.true[1,])
sim.dat <- matrix(0, nrow=N, ncol=m)

est.parFPC1 <- est.parFPC2 <- est.parFPC3 <- matrix(0, nrow=n, ncol=m)
est.nparFPC1 <- est.nparFPC2 <- est.nparFPC3 <- matrix(0, nrow=n, ncol=m)
#define bias and sd 
bias.parFPC1 <- bias.parFPC2 <- bias.parFPC3 <- rep(0, m)
bias.nparFPC1 <- bias.nparFPC2 <- bias.nparFPC3 <- rep(0, m)
sd.parFPC1 <- sd.parFPC2 <- sd.parFPC3 <- rep(0, m)
sd.nparFPC1 <- sd.nparFPC2 <- sd.nparFPC3 <- rep(0, m)

set.seed(20151114)



  for(i in 1:n)
  { #i = 1
    
    eig.score.true <- rmvnorm(N,sigma=diag(eigv.true))
    #eig.score.out <- rmvnorm(N,sigma=diag(eigv.out))
    
    for(j in 1:N)
      sim.dat[j,] <- mean.curve + FPC.true %*% eig.score.true[j,]
    
  #  sim.fit <- smooth.basisPar(argvals=timepts.fine, y=t(sim.dat),fdobj=eggbasis.bs,
  #                             Lfdobj=Lfdobjheight,lambda=0)
    sim.fd <- Data2fd(argvals=timepts.fine, y=t(sim.dat),basisobj=eggbasis.bs,lambda=0)
  #  sim.fd <- sim.fit$fd
    PCAobjects.bs=pca.fd(sim.fd, nharm = 3, fdParobj.bs)
    PCAobjects.mon=pca.fd(sim.fd, nharm = 3,fdParobj.mon)
    est.nparFPC1[i,] <- basismat.fine%*%PCAobjects.bs$harmonics$coefs[,1]
    est.nparFPC1[i,] <- sig[1]*sign(est.nparFPC1[i,1])*est.nparFPC1[i,]
    est.nparFPC2[i,] <- basismat.fine%*%PCAobjects.bs$harmonics$coefs[,2]
    est.nparFPC2[i,] <- sig[2]*sign(est.nparFPC2[i,1])*est.nparFPC2[i,]
    est.nparFPC3[i,] <- basismat.fine%*%PCAobjects.bs$harmonics$coefs[,3]
    est.nparFPC3[i,] <- sig[3]*sign(est.nparFPC3[i,1])*est.nparFPC3[i,]
    est.parFPC1[i,] <- basismat.mon%*%PCAobjects.mon$harmonics$coefs[,1]
    est.parFPC1[i,] <- sig[1]*sign(est.parFPC1[i,1])*est.parFPC1[i,]
    est.parFPC2[i,] <- basismat.mon%*%PCAobjects.mon$harmonics$coefs[,2]
    est.parFPC2[i,] <- sig[2]*sign(est.parFPC2[i,1])*est.parFPC2[i,]
    est.parFPC3[i,] <- basismat.mon%*%PCAobjects.mon$harmonics$coefs[,3]
    est.parFPC3[i,] <- sig[3]*sign(est.parFPC3[i,1])*est.parFPC3[i,]
  }
  bias.nparFPC1 <- apply(est.nparFPC1,2,mean) - FPC.true[,1]
  bias.nparFPC2 <- apply(est.nparFPC2,2,mean) - FPC.true[,2]
  bias.nparFPC3 <- apply(est.nparFPC3,2,mean) - FPC.true[,3]
  
  sd.nparFPC1 <- apply(est.nparFPC1,2,sd) 
  sd.nparFPC2 <- apply(est.nparFPC2,2,sd) 
  sd.nparFPC3 <- apply(est.nparFPC3,2,sd) 
  
  bias.parFPC1 <- apply(est.parFPC1,2,mean) - FPC.true[,1]
  bias.parFPC2 <- apply(est.parFPC2,2,mean) - FPC.true[,2]
  bias.parFPC3 <- apply(est.parFPC3,2,mean) - FPC.true[,3]
  
  sd.parFPC1<- apply(est.parFPC1,2,sd) 
  sd.parFPC2 <- apply(est.parFPC2,2,sd) 
  sd.parFPC3 <- apply(est.parFPC3,2,sd) 
  


#bias, se and rmse for both np FPCA and p-FPCA

rmse.nparFPC1 <- sqrt(bias.nparFPC1^2 + sd.nparFPC1^2)
rmse.nparFPC2 <- sqrt(bias.nparFPC2^2 + sd.nparFPC2^2)
rmse.nparFPC3 <- sqrt(bias.nparFPC3^2 + sd.nparFPC3^2)
rmse.parFPC1 <- sqrt(bias.parFPC1^2 + sd.parFPC1^2)
rmse.parFPC2 <- sqrt(bias.parFPC2^2 + sd.parFPC2^2)
rmse.parFPC3 <- sqrt(bias.parFPC3^2 + sd.parFPC3^2)

# open a new graph window in R in a Windows laptop.
# run quartz() if you are using a Mac computer
windows()

par(mfrow=c(3,3),lwd=3,cex.lab=1.2,oma=c(0,1,0,0))
plot(x=timepts.fine,y=bias.nparFPC1,type="l",lty=2,xlab="Time",ylab="Bias",ylim=range(bias.parFPC1))
points(x=timepts.fine,y=bias.parFPC1,type="l",lty=1)
plot(x=timepts.fine,y=bias.nparFPC2,type="l",lty=2, xlab="Time", ylab="Bias", ylim=range(bias.parFPC2))
points(x=timepts.fine,y=bias.parFPC2,type="l",lty=1)
plot(x=timepts.fine,y=bias.nparFPC3,type="l",lty=2, xlab="Time", ylab="Bias",
     ylim=range(bias.parFPC3))
points(x=timepts.fine,y=bias.parFPC3,type="l",lty=1)

plot(x=timepts.fine,y=sd.nparFPC1,type="l",lty=2, xlab="Time", ylab="Standard Error")
points(x=timepts.fine,y=sd.parFPC1,type="l",lty=1)
plot(x=timepts.fine,y=sd.nparFPC2,type="l",lty=2, xlab="Time", ylab="Standard Error")
points(x=timepts.fine,y=sd.parFPC2,type="l",lty=1)
plot(x=timepts.fine,y=sd.nparFPC3,type="l",lty=2, xlab="Time", ylab="Standard Error")
points(x=timepts.fine,y=sd.parFPC3,type="l",lty=1)

plot(x=timepts.fine,y=rmse.nparFPC1,type="l",lty=2, xlab="Time", ylab="RMSE",
     ylim=range(rmse.parFPC1))
points(x=timepts.fine,y=rmse.parFPC1,type="l",lty=1)
plot(x=timepts.fine,y=rmse.nparFPC2,type="l",lty=2, xlab="Time", ylab="RMSE", ylim=range(rmse.parFPC2))
points(x=timepts.fine,y=rmse.parFPC2,type="l",lty=1)
plot(x=timepts.fine,y=rmse.nparFPC3,type="l",lty=2, xlab="Time", ylab="RMSE",
     ylim=range(rmse.parFPC3))
points(x=timepts.fine,y=rmse.parFPC3,type="l",lty=1)


#============================================
#randomly select 30% outliers
#then compare P-FPCA and NP-FPCA

cand.per <- 0.3
n <- 100

est.parFPC1 <- est.parFPC2 <- est.parFPC3 <- matrix(0, nrow=n, ncol=m)
est.nparFPC1 <- est.nparFPC2 <- est.nparFPC3 <- matrix(0, nrow=n, ncol=m)
#define bias and sd 
bias.parFPC1 <- bias.parFPC2 <- bias.parFPC3 <- rep(0, m)
bias.nparFPC1 <- bias.nparFPC2 <- bias.nparFPC3 <- rep(0, m)
sd.parFPC1 <- sd.parFPC2 <- sd.parFPC3 <- rep(0, m)
sd.nparFPC1 <- sd.nparFPC2 <- sd.nparFPC3 <- rep(0, m)

set.seed(20151114)
# eig.score.true <- rmvnorm(N,sigma=diag(eigv.true))
# eig.score.out <- rmvnorm(N,sigma=diag(eigv.out))
# for(i in 1:N)
#   sim.dat[i,] <- mean.curve + FPC.true %*% eig.score.true[i,]



  for(i in 1:n)
  { #i = 1
    eig.score.true <- rmvnorm(N,sigma=diag(eigv.true))
    for(j in 1:N)
      sim.dat[j,] <- mean.curve + FPC.true %*% eig.score.true[j,]
    
    out.sub <- sample(1:N, size=N*cand.per, replace=F)
    sim.out <- sim.dat
    sim.out[out.sub,] <-  rmvnorm(N*cand.per,sigma=diag(eigv.out[1:2]*30)) %*% t(FPC.out[,1:2]) 
    #scale the variance of outlier curves to make them comparable with uncontaminated curves
    
    sim.fit <- smooth.basisPar(argvals=timepts.fine,
                               y=t(sim.out), fdobj=eggbasis.bs,
                               Lfdobj=Lfdobjheight, lambda=0)
    sim.fd <- sim.fit$fd
    PCAobjects.bs.out=pca.fd(sim.fd, nharm = 3)
    PCAobjects.mon.out=pca.fd(sim.fd, nharm = 3,fdParobj.mon)
   
    est.nparFPC1[i,] <- basismat.fine%*%PCAobjects.bs.out$harmonics$coefs[,1]
    est.nparFPC1[i,] <- sig[1]*sign(est.nparFPC1[i,1])*est.nparFPC1[i,]
    est.nparFPC2[i,] <- basismat.fine%*%PCAobjects.bs.out$harmonics$coefs[,2]
    est.nparFPC2[i,] <- sig[2]*sign(est.nparFPC2[i,1])*est.nparFPC2[i,]
    est.nparFPC3[i,] <- basismat.fine%*%PCAobjects.bs.out$harmonics$coefs[,3]
    est.nparFPC3[i,] <- sig[3]*sign(est.nparFPC3[i,1])*est.nparFPC3[i,]
    est.parFPC1[i,] <- basismat.mon%*%PCAobjects.mon.out$harmonics$coefs[,1]
    est.parFPC1[i,] <- sig[1]*sign(est.parFPC1[i,1])*est.parFPC1[i,]
    est.parFPC2[i,] <- basismat.mon%*%PCAobjects.mon.out$harmonics$coefs[,2]
    est.parFPC2[i,] <- sig[2]*sign(est.parFPC2[i,1])*est.parFPC2[i,]
    est.parFPC3[i,] <- basismat.mon%*%PCAobjects.mon.out$harmonics$coefs[,3]
    est.parFPC3[i,] <- sig[3]*sign(est.parFPC3[i,1])*est.parFPC3[i,]
  }
bias.nparFPC1 <- apply(est.nparFPC1,2,mean) - FPC.true[,1]
bias.nparFPC2 <- apply(est.nparFPC2,2,mean) - FPC.true[,2]
bias.nparFPC3 <- apply(est.nparFPC3,2,mean) - FPC.true[,3]

sd.nparFPC1 <- apply(est.nparFPC1,2,sd) 
sd.nparFPC2 <- apply(est.nparFPC2,2,sd) 
sd.nparFPC3 <- apply(est.nparFPC3,2,sd) 

bias.parFPC1 <- apply(est.parFPC1,2,mean) - FPC.true[,1]
bias.parFPC2 <- apply(est.parFPC2,2,mean) - FPC.true[,2]
bias.parFPC3 <- apply(est.parFPC3,2,mean) - FPC.true[,3]

sd.parFPC1<- apply(est.parFPC1,2,sd) 
sd.parFPC2 <- apply(est.parFPC2,2,sd) 
sd.parFPC3 <- apply(est.parFPC3,2,sd) 

  


#randomly select several curves in the sample to plot
index1 <- sample(out.sub, size=9)
index2 <- sample((1:N)[-out.sub],size=21)

# open a new graph window in R in a Windows laptop.
# run quartz() if you are using a Mac computer
windows()
par(mfrow=c(1,1),lwd=3,cex.lab=1.2,oma=c(0,1,0,0))
matplot(x=timepts.fine, y=t(sim.out[index2,]),type="l",lty=1,col="red",xlab="t", ylab="X(t)")
matpoints(x=timepts.fine, y=t(sim.out[index1,]),type="l",lty=2,col="blue")

#=========================================
#bias, se and rmse for both np FPCA and p-FPCA

rmse.nparFPC1 <- sqrt(bias.nparFPC1^2 + sd.nparFPC1^2)
rmse.nparFPC2 <- sqrt(bias.nparFPC2^2 + sd.nparFPC2^2)
rmse.nparFPC3 <- sqrt(bias.nparFPC3^2 + sd.nparFPC3^2)
rmse.parFPC1 <- sqrt(bias.parFPC1^2 + sd.parFPC1^2)
rmse.parFPC2 <- sqrt(bias.parFPC2^2 + sd.parFPC2^2)
rmse.parFPC3 <- sqrt(bias.parFPC3^2 + sd.parFPC3^2)

# open a new graph window in R in a Windows laptop.
# run quartz() if you are using a Mac computer
windows()

par(mfrow=c(3,3),lwd=3,cex.lab=1.2,oma=c(0,1,0,0),font.lab=2)
plot(x=timepts.fine,y=bias.nparFPC1,type="l",lty=2, xlab="Time", ylab="Bias")
points(x=timepts.fine,y=bias.parFPC1,type="l",lty=1)
plot(x=timepts.fine,y=bias.nparFPC2,type="l",lty=2, xlab="Time", ylab="Bias")
points(x=timepts.fine,y=bias.parFPC2,type="l",lty=1)
plot(x=timepts.fine,y=bias.nparFPC3,type="l",lty=2, xlab="Time", ylab="Bias")
points(x=timepts.fine,y=bias.parFPC3,type="l",lty=1)

plot(x=timepts.fine,y=sd.nparFPC1,type="l",lty=2, xlab="Time", ylab="Standard Error",ylim=range(sd.parFPC1))
points(x=timepts.fine,y=sd.parFPC1,type="l",lty=1)
plot(x=timepts.fine,y=sd.nparFPC2,type="l",lty=2, xlab="Time", ylab="Standard Error")
points(x=timepts.fine,y=sd.parFPC2,type="l",lty=1)
plot(x=timepts.fine,y=sd.nparFPC3,type="l",lty=2, xlab="Time", ylab="Standard Error")
points(x=timepts.fine,y=sd.parFPC3,type="l",lty=1)

plot(x=timepts.fine,y=rmse.nparFPC1,type="l",lty=2, xlab="Time", ylab="RMSE")
points(x=timepts.fine,y=rmse.parFPC1,type="l",lty=1)
plot(x=timepts.fine,y=rmse.nparFPC2,type="l",lty=2, xlab="Time", ylab="RMSE")
points(x=timepts.fine,y=rmse.parFPC2,type="l",lty=1)
plot(x=timepts.fine,y=rmse.nparFPC3,type="l",lty=2, xlab="Time", ylab="RMSE")
points(x=timepts.fine,y=rmse.parFPC3,type="l",lty=1)


