
install.packages("fda")
library('fda')
#provide the directory where the data set is stored
dat <- read.table("cd4.dat",header=T)
#head(dat)
cd4.dat <- dat[,c(1,6,2)]
#head(cd4.dat)



#data.m <- easy$data
nmax<-max(table(cd4.dat[,1]))  ##maximum number of measurements per subject 
#14
median(table(cd4.dat[,1]))
#6
L1<-min(as.numeric(cd4.dat[,3]))  ##range of the time 
#0.1
L2<-max(as.numeric(cd4.dat[,3]))
#5.9
grid.l=seq(0,1,0.01)
grids=seq(0,1,0.002)

#===================================================
#estimated from Fang Yao's method
#provide the directory of pace
install.packages(c("PACE.zip", "caTools", "signal"))
library(PACE) #it has been removed from CRAN
head(cd4.dat)
N <- length(unique(cd4.dat[,1]))
#283
time <- cd4.dat$Time
obs <- cd4.dat$CD4
sub <- cd4.dat$subj

# open a new graph window in R in a Windows laptop.
# run quartz() if you are using a Mac computer
windows()
par(mfrow=c(1,1),cex.lab=1.2,oma=c(0,1,0,0))
plot(x=time[which(sub==1)], y=obs[which(sub==1)],xlab="Year", ylab="CD4 Percentage",
     type="l",ylim=c(0,70), xlim=c(0,6))
for(i in 2:N)
  lines(x=time[which(sub==i)], y=obs[which(sub==i)])


CD4 <- matrix(NA,nrow=N,ncol=nmax)
for(i in 1:N)
{
  size <- length(which(cd4.dat$subj==i))
  CD4[i,1:size] <- cd4.dat[cd4.dat$subj==i,2]
}
head(CD4)

tt <- matrix(NA,nrow=N,ncol=nmax)
for(i in 1:N)
{
  size <- length(which(cd4.dat$subj==i))
  tt[i,1:size] <- (cd4.dat[cd4.dat$subj==i,3]-L1)/(L2-L1)
}
head(tt)


p = setOptions(regular = 0, selection_k = "BIC1", screePlot = 1, 
               designPlot = 1, numBins = 0, verbose = "on",ngrid=200, maxk=5);
yy = FPCA(CD4,tt, p)
#0.1860724 
#( 0.1259016 , 0.1259016 )
#the result is stored at cd4analysis.RData

#provide directory of this data
load("cd4analysis.RData",verbose=T)


##extract some of the results for plots
out1 = getVal(yy,"out1") #vector of time points for mu, phi and y_pred
mu = getVal(yy,"mu")     #estimated mean function that is evaluated at out1
out21 = getVal(yy,"out21") #vector of time points for covariance function
xcovfit = getVal(yy, "xcovfit") #fitted covariance surface evaluated at out21 for both x and y direction
xcov = getVal(yy, "xcov")       #estimated smooth covariance evaluated at out21 for both x and y direction
phi = getVal(yy, "phi")         #estimated eigenfunctions evaluated at out1
no_opt = getVal(yy, "no_opt")
sig = getVal(yy,"sigma")
lam = getVal(yy,"lambda")
#85.171109  9.621128  4.602335  0.664419
fve = getVal(yy,"FVE")
#0.8511258 0.9472710 0.9932627 0.9999024





#===============================================
## Trape2D uses Trapezoidal rule to compute the integration
## INPUT:
## t = vector at which the function values are specified
## f = values of functions of which the integration are to be computed, values must be specified at t
## OUTPUT: value of the integration
Trape2D <- function(t,f)
{
  m = length(t)
  weight = rbind(t(c(1,rep(2,length(t)-2),1)),cbind(rep(2,length(t)-2),
  matrix(4,nrow=length(t)-2,ncol=length(t)-2),rep(2,length(t)-2)),t(c(1,rep(2,length(t)-2),1)))
  return(sum(f*weight)/((length(t)-1)^2*4))
}


#===============================================
#P-FPCA from (smoothed) covariance matrix
library(fda)
library(caTools)
library(signal)
#temp <- grids[2]-grids[1]

#parametric FPCA

timepts <- unique(c(out1,out21))
head(timepts)
timepts <- timepts[order(timepts)]
head(timepts)
pc1.bs <- phi[,1]

#interpolation using piece-wise cubic splines
pc1.bs <- pchip(out1, pc1.bs, xi=timepts)
# plot(x=timepts, y=pc1.bs, type="l")



sig <- sign(pc1.bs[1])

p <- 1:5
dist <- numeric(length(p))
for(j in p)
{ #j = 1
  mon.basis <- create.monomial.basis(range(out21), j + 1)
  basismat   = eval.basis(out21, mon.basis);
  #Wmat <- crossprod(basismat)*temp
  Wmat <- matrix(0,nrow=j+1,ncol=j+1)
  for(i in 1:(j+1))
    for(k in 1:(j+1))
      Wmat[i,k] <- Trape2D(t=out21,f=t(basismat)[i,]*basismat[,k])
  Amat <- matrix(0,nrow=length(out21),ncol=j+1)
  for(i in 1:length(out21))
    for(k in 1:(j+1))
      Amat[i,k] <- Trape2D(t=out21,f=xcov[i,]*basismat[,k])
  #Kmat <- crossprod(basismat,Amat)*temp
  Kmat <- matrix(0,nrow=j+1,ncol=j+1)
  for(i in 1:(j+1))
    for(k in 1:(j+1))
      Kmat[i,k] <- Trape2D(t=out21,f=t(basismat)[i,]*Amat[,k])
  Kmat.val <- eigen(Kmat)$values
  Kinv <- solve(Kmat)
  
  result <- eigen(Wmat)
  Wsqrt <- result$vectors %*% sqrt(diag(result$values)) %*% t(result$vectors)
  result <- eigen(Wsqrt %*% Kinv %*% Wsqrt)
  
  eigval <- 1/result$values
  #0.6155202  4.3920055  9.4541668 84.7680893
  eigvec <- solve(Wsqrt) %*% result$vectors[,-1]
  eigenf.p <- basismat %*% eigvec
  pc1.mon <- eigenf.p[,j]
  pc1.mon <- pchip(out21, pc1.mon, timepts)
  pc1.mon <- sig*sign(pc1.mon[1])*pc1.mon
  dist[j] <-  trapz(x=timepts, y=abs(pc1.mon-pc1.bs))
  
}

windows()
par(lwd=3,cex.lab=1.6, font.lab=2,mar=c(5,4.8,4,2))
plot(x=p, y=dist, xlab="p", ylab="J(p)", type="l")

#choose p = 2


mon.basis <- create.monomial.basis(range(out21), 3)
basismat   = eval.basis(out21, mon.basis);
#Wmat <- crossprod(basismat)*temp
Wmat <- matrix(0,nrow=3,ncol=3)
for(i in 1:3)
  for(k in 1:3)
    Wmat[i,k] <- Trape2D(t=out21,f=t(basismat)[i,]*basismat[,k])
Amat <- matrix(0,nrow=length(out21),ncol=3)
for(i in 1:length(out21))
  for(k in 1:3)
    Amat[i,k] <- Trape2D(t=out21,f=xcov[i,]*basismat[,k])
#Kmat <- crossprod(basismat,Amat)*temp
Kmat <- matrix(0,nrow=3,ncol=3)
for(i in 1:3)
  for(k in 1:3)
    Kmat[i,k] <- Trape2D(t=out21,f=t(basismat)[i,]*Amat[,k])
Kmat.val <- eigen(Kmat)$values
Kinv <- solve(Kmat)

result <- eigen(Wmat)
Wsqrt <- result$vectors %*% sqrt(diag(result$values)) %*% t(result$vectors)
result <- eigen(Wsqrt %*% Kinv %*% Wsqrt)

eigval <- 1/result$values
# 4.290328  9.447019 84.767088
eigvec <- solve(Wsqrt) %*% result$vectors[,-1]
eigenf.p <- basismat %*% eigvec
pc1.mon <- eigenf.p[,2]
pc1.mon <- pchip(out21, pc1.mon, timepts)
pc1.mon <- sig*sign(pc1.mon[1])*pc1.mon





# open a new graph window in R in a Windows laptop.
# run quartz() if you are using a Mac computer

windows()
#pdf("cd4.pdf")
par(mfrow=c(1,1),lwd=3,cex.lab=1.3,font.lab=2,mar=c(5,4.7,4,2))
plot(x=timepts,y=pc1.mon,type="l",lty=1,xlab="Year",ylab="")
#plot(x=grids,y=eigenfest[,1],type="o",lty=2,col="blue")
mtext(side=2,text="FPC1",line=2.5,font=1.5,cex=1.1)
points(x=timepts,y=pc1.bs,type="l",lty=2)
legend(0.2,0.8,legend=c("P-FPCA","NP-FPCA"),bty="n",lty=1:2)
#dev.off()

# plot(x=out21,y=(-1)*eigenf.p[,2],lty=1,type="l",
#      xlab="Year",ylab="",ylim=c(-1.9,1.3))
# mtext(side=2,text="FPC2",line=2.5,font=1.5,cex=1.1)
# points(x=out1,y=phi[,2],type="l",lty=2)
# legend(0.3,-1.0,legend=c("P-FPCA","NP-FPCA"),bty="n",
#        lty=1:2)
# plot(x=out21,y=(-1)*eigenf.p[,1],lty=1,type="l",
#      xlab="Year",ylab="",ylim=c(-2.5,1.3))
# mtext(side=2,text="FPC3",line=2.5,font=1.5,cex=1.1)
# points(x=out1,y=phi[,3],type="l",lty=2)
# legend(0.2,-1.0,legend=c("P-FPCA","NP-FPCA"),bty="n",
#        lty=1:2)


