

install.packages(c("fda","caTools"))

library(fda)
heightbasis.bs <-  create.bspline.basis(rangeval=c(1,18),nbasis=33,
                                        norder=4,breaks=growth$age)
Lfdobjheight<- int2Lfd(2)


# open a new graph window in R in a Windows laptop.
# run quartz() if you are using a Mac computer

windows()
par(mfrow=c(1,1),lwd=3,cex.lab=1.2,oma=c(0,1,0,0))
matplot(x=growth$age, y=growth$hgtf,type="l",xlab="Age", ylab="Height")

#==========================
#choosing tuning parameter to smooth heightbasis
loglam <- -4:2
nlam = length(loglam)
gcvsave = rep(NA,nlam)
for (i in 1:nlam) {
  #i=1
  lambda   = 10^loglam[i]
  fdParobj = fdPar(heightbasis.bs, int2Lfd(2), lambda)
  smoothlist = smooth.basis(growth$age, growth$hgtf,fdParobj,dfscale=1.2)
#   xfd=smoothlist$fd
#   eval.fd(growth$age,xfd)
  gcvsave[i] = sum(smoothlist$gcv)
}

# open a new graph window in R in a Windows laptop.
# run quartz() if you are using a Mac computer
windows()
plot(x=loglam,y=gcvsave,xlab="log(lam)",ylab="gcv")

lamb <- 10^(loglam[which.min(gcvsave)+1])
#0.01


height <- smooth.basisPar(argvals=growth$age,
                           y=growth$hgtf, fdobj=heightbasis.bs,
                         Lfdobj=Lfdobjheight, lambda=lamb)
height.fd = height$fd
 


nharm = 3
height.pcalist.bs = pca.fd(height.fd, nharm=3)
sum(height.pcalist.bs$values)
#541.9861


height.pcalist.bs$varprop
#0.89302041 0.06418290 0.02527632
coef.bs <- height.pcalist.bs$harmonics$coefs

randfd1.bs = fd(coef.bs[,1],heightbasis.bs)
pc1.bs = eval.fd(growth$age,randfd1.bs)
# randfd2.bs = fd(coef.bs[,2],heightbasis.bs)
# fdvals2.bs = eval.fd(growth$age,randfd2.bs)
# randfd3.bs = fd(coef.bs[,3],heightbasis.bs)
# fdvals3.bs = eval.fd(growth$age,randfd3.bs)

library(caTools)
p <- 1:5
dist <- numeric(length(p))
for(j in p)
{ #j = 2
heightbasis.mon <- create.monomial.basis(c(1,18), j+1)
fdParobj.mon= fdPar(heightbasis.mon,int2Lfd(0),lambda=0)
height.pcalist.mon = pca.fd(height.fd, nharm=2, fdParobj.mon)
coef.mon <- height.pcalist.mon$harmonics$coefs
randfd1.mon = fd(coef.mon[,1],heightbasis.mon)
pc1.mon <- eval.fd(growth$age,randfd1.mon)
dist[j] <- trapz(x=growth$age, y=abs(pc1.mon-pc1.bs)) 
}

windows()
par(lwd=3,cex.lab=1.6, font.lab=2,mar=c(5,4.8,4,2))
plot(x=p, y=dist, xlab="p", ylab="J(p)", type="l")


#choose p = 3
heightbasis.mon <- create.monomial.basis(c(1,18), 3+1)
fdParobj.mon= fdPar(heightbasis.mon,int2Lfd(0),lambda=0)
height.pcalist.mon = pca.fd(height.fd, nharm=2, fdParobj.mon)

height.pcalist.mon$values[1]/sum(height.pcalist.bs$values)
#89.1%
coef.mon <- height.pcalist.mon$harmonics$coefs
randfd1.mon = fd(coef.mon[,1],heightbasis.mon)
pc1.mon <- eval.fd(growth$age,randfd1.mon)
# randfd2.mon = fd(coef.mon[,2],heightbasis.mon)
# randfd3.mon = fd(coef.mon[,3],heightbasis.mon)
# open a new graph window in R in a Windows laptop.
# run quartz() if you are using a Mac computer
windows()
par(mfrow=c(1,1),lwd=3,cex.lab=1.2,oma=c(0,1,0,0))
plot(growth$age, pc1.mon,lty=1,ylab="FPC 1",ylim=c(0.1,0.32),xlab="age", type="l")
points(x=growth$age,y=pc1.bs,type="l",lty=2)
legend(5,0.2,legend=c("P-FpCA","NP-FPCA"),bty="n",lty=1:2)


# plot(randfd2.mon,lty=1,ylab="FPC 2",ylim=c(-0.32,0.38),
#      xlab="age")
# points(x=growth$age,y=fdvals2.bs,type="l",lty=2)
# legend(3,0.3,legend=c("P-FPCA","NP-FPCA"),
#        bty="n",lty=1:2)
# 
# 
# plot(randfd3.mon,lty=1,ylab="FPC 3",ylim=c(-0.38,0.38),
#      xlab="age")
# points(x=growth$age,y=fdvals3.bs,type="l",lty=2)
# legend(5.5,0.4,legend=c("P-FPCA","NP-FPCA"),
#        bty="n",lty=1:2)

