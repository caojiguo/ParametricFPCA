

install.packages(c("fda","ggplot2", "caTools"))
#================
#fpca with monomial basis for the Canada precipitation data

library(fda)
library(ggplot2)
logprecav = CanadianWeather$dailyAv[
  dayOfYearShifted, , 'log10precip']
dayrange  = c(0,365)

# open a new graph window in R in a Windows laptop.
# run quartz() if you are using a Mac computer
windows()
par(mfrow=c(1,1),lwd=3,cex.lab=1.2,oma=c(0,1,0,0))
matplot(x=1:365, y=logprecav ,type="l",xlab="Day", ylab= expression(paste(log[10], "(Precipitation)")))




# monomial basis (parametric fpca) and Fourier basis (nonparametric fpca)
# using Fourier basis to generate and smooth fd obj


daybasis2  = create.fourier.basis(dayrange,365)
Lcoef        = c(0,(2*pi/diff(dayrange))^2,0)
harmaccelLfd = vec2Lfd(Lcoef, dayrange)
loglam <- 1:9
nlam = length(loglam)
  # vector to contain d.o.f
gcvsave = rep(NA,nlam)
for (i in 1:nlam) {
  lambda   = 10^loglam[i]
  fdParobj.har  = fdPar(daybasis2, harmaccelLfd, lambda)
  smoothlist = smooth.basis(day.5, logprecav,fdParobj.har,dfscale=1.2)
  gcvsave[i] = sum(smoothlist$gcv)
}

# open a new graph window in R in a Windows laptop.
# run quartz() if you are using a Mac computer
windows()
plot(gcvsave)
lambda <- 10^(loglam[which.min(gcvsave)])
#10^6

logprec.fit <- smooth.basisPar(argvals=day.5,
                      y=logprecav, fdobj=daybasis2,
                        Lfdobj=harmaccelLfd, lambda=lambda)
logprec.fd  = logprec.fit$fd


#=========================================
#nonparametric fpca
logprec.pcalist.four = pca.fd(logprec.fd, nharm=3)
coef.four <- logprec.pcalist.four$harmonics$coefs
#nonparametric fpca
logprec.pcalist.four$varprop 
# 0.87380464 0.08594466 0.02147512

randfd1.four = fd(coef.four[,1],daybasis2)
pc1.four = eval.fd(0:365,randfd1.four)

# randfd2.four = fd(coef.four[,2],daybasis2)
# fdvals2.four = eval.fd(0:365,randfd2.four)
# randfd3.four = fd(coef.four[,3],daybasis2)
# fdvals3.four = eval.fd(0:365,randfd3.four)



library(caTools)

p <- 1:5
dist <- numeric(length(p))
for(j in p)
{
  daybasis1  = create.monomial.basis(dayrange, j+1)
  fdParobj.mon= fdPar(daybasis1,int2Lfd(0),lambda=0)
  #parametric fpca
  logprec.pcalist.mon = pca.fd(logprec.fd, nharm=2, fdParobj.mon)
  coef.mon <- logprec.pcalist.mon$harmonics$coefs
  randfd1.mon = fd(coef.mon[,1],daybasis1)
  pc1.mon = eval.fd(0:365,randfd1.mon)
#   randfd2.mon = fd(coef.mon[,2],daybasis1)
#   randfd3.mon = fd(coef.mon[,3],daybasis1)
  dist[j] <- trapz(x=0:365, y=abs(pc1.mon-pc1.four))  
}

windows()
par(lwd=3,cex.lab=1.6, font.lab=2,mar=c(5,4.8,4,2))
plot(x=p, y=dist, xlab="p", ylab="J(p)", type="l")

#choose p = 2


daybasis1  = create.monomial.basis(dayrange, 3)
fdParobj.mon= fdPar(daybasis1,int2Lfd(0),lambda=0)
#parametric fpca
logprec.pcalist.mon = pca.fd(logprec.fd, nharm=3, fdParobj.mon)
coef.mon <- logprec.pcalist.mon$harmonics$coefs
randfd1.mon = fd(coef.mon[,1],daybasis1)
pc1.mon = eval.fd(0:365,randfd1.mon)
# randfd2.mon = fd(coef.mon[,2],daybasis1)
# randfd3.mon = fd(coef.mon[,3],daybasis1)


logprec.pcalist.mon$values/sum(logprec.pcalist.four$values)
#0.86659721 0.07972975 0.01556993





# open a new graph window in R in a Windows laptop.
# run quartz() if you are using a Mac computer
windows() 
par(mfrow=c(1,1),lwd=3,cex.lab=1.2,oma=c(0,1,0,0))
plot(0:365, pc1.mon,type="l",lty=1,lwd=3,xlab="Day",ylab="FPC 1")
points(x=0:365,y=pc1.four,type="l",lty=2)
legend(80,0.03,legend=c("P-FPCA","NP-FPCA"),lty=1:2,bty="n")



# plot(randfd2.mon,lty=1,lwd=3,xlab="Day",ylab="FPC 2")
# points(x=0:365,y=fdvals2.four,type="l",lty=2)
# legend(80,0.12,legend=c("P-FPCA","NP-FPCA"),lty=1:2,bty="n")
# 
# 
# plot((-1)*randfd3.mon,lty=1,lwd=3,
#      ylim=c(-0.075,0.09),xlab="Day",ylab="FPC 3")
# points(x=0:365,y=fdvals3.four,type="l",lty=2)
# legend(30,-0.05,legend=c("P-FPCA","NP-FPCA"),lty=1:2,bty="n")


